﻿namespace BlazorMenu.Constants.Storage
{
    public static class StorageConstants
    {
        public static string AuthToken = "authToken";
        public static string Culture = "culture";
        //public static string TokenId = "tokenId";
        public static string CultureInfo = "cultureInfo";
    }
}
