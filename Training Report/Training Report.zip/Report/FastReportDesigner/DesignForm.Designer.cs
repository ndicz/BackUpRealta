﻿namespace FastReportDesigner
{
    partial class DesignForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnProduct = new System.Windows.Forms.Button();
            this.btnReportInherit = new System.Windows.Forms.Button();
            this.btnReportBaseHeader = new System.Windows.Forms.Button();
            this.btnGlobalization = new System.Windows.Forms.Button();
            this.btnHeaderDetail = new System.Windows.Forms.Button();
            this.btnParentChildSalesmanProduct = new System.Windows.Forms.Button();
            this.btnGroupSalesmanProduct = new System.Windows.Forms.Button();
            this.btnMatrixSalesmanProduct = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnProduct
            // 
            this.btnProduct.Location = new System.Drawing.Point(3, 2);
            this.btnProduct.Name = "btnProduct";
            this.btnProduct.Size = new System.Drawing.Size(177, 23);
            this.btnProduct.TabIndex = 3;
            this.btnProduct.Text = "Product Object";
            this.btnProduct.UseVisualStyleBackColor = true;
            this.btnProduct.Click += new System.EventHandler(this.btnProduct_Click);
            // 
            // btnReportInherit
            // 
            this.btnReportInherit.Location = new System.Drawing.Point(3, 89);
            this.btnReportInherit.Name = "btnReportInherit";
            this.btnReportInherit.Size = new System.Drawing.Size(177, 23);
            this.btnReportInherit.TabIndex = 5;
            this.btnReportInherit.Text = "Report Inherit";
            this.btnReportInherit.UseVisualStyleBackColor = true;
            this.btnReportInherit.Click += new System.EventHandler(this.btnReportInherit_Click);
            // 
            // btnReportBaseHeader
            // 
            this.btnReportBaseHeader.Location = new System.Drawing.Point(3, 60);
            this.btnReportBaseHeader.Name = "btnReportBaseHeader";
            this.btnReportBaseHeader.Size = new System.Drawing.Size(177, 23);
            this.btnReportBaseHeader.TabIndex = 10;
            this.btnReportBaseHeader.Text = "Report Base Header";
            this.btnReportBaseHeader.UseVisualStyleBackColor = true;
            this.btnReportBaseHeader.Click += new System.EventHandler(this.btnReportBaseHeader_Click);
            // 
            // btnGlobalization
            // 
            this.btnGlobalization.Location = new System.Drawing.Point(3, 31);
            this.btnGlobalization.Name = "btnGlobalization";
            this.btnGlobalization.Size = new System.Drawing.Size(177, 23);
            this.btnGlobalization.TabIndex = 11;
            this.btnGlobalization.Text = "Globalization";
            this.btnGlobalization.UseVisualStyleBackColor = true;
            this.btnGlobalization.Click += new System.EventHandler(this.btnGlobalization_Click);
            // 
            // btnHeaderDetail
            // 
            this.btnHeaderDetail.Location = new System.Drawing.Point(200, 2);
            this.btnHeaderDetail.Name = "btnHeaderDetail";
            this.btnHeaderDetail.Size = new System.Drawing.Size(152, 23);
            this.btnHeaderDetail.TabIndex = 12;
            this.btnHeaderDetail.Text = "Report Header Detail";
            this.btnHeaderDetail.UseVisualStyleBackColor = true;
            this.btnHeaderDetail.Click += new System.EventHandler(this.btnHeaderDetail_Click);
            // 
            // btnParentChildSalesmanProduct
            // 
            this.btnParentChildSalesmanProduct.Location = new System.Drawing.Point(387, 60);
            this.btnParentChildSalesmanProduct.Name = "btnParentChildSalesmanProduct";
            this.btnParentChildSalesmanProduct.Size = new System.Drawing.Size(200, 23);
            this.btnParentChildSalesmanProduct.TabIndex = 15;
            this.btnParentChildSalesmanProduct.Text = "Parent Child Salesman Product";
            this.btnParentChildSalesmanProduct.UseVisualStyleBackColor = true;
            this.btnParentChildSalesmanProduct.Click += new System.EventHandler(this.btnParentChildSalesmanProduct_Click);
            // 
            // btnGroupSalesmanProduct
            // 
            this.btnGroupSalesmanProduct.Location = new System.Drawing.Point(387, 2);
            this.btnGroupSalesmanProduct.Name = "btnGroupSalesmanProduct";
            this.btnGroupSalesmanProduct.Size = new System.Drawing.Size(200, 23);
            this.btnGroupSalesmanProduct.TabIndex = 14;
            this.btnGroupSalesmanProduct.Text = "Group Salesman Product";
            this.btnGroupSalesmanProduct.UseVisualStyleBackColor = true;
            this.btnGroupSalesmanProduct.Click += new System.EventHandler(this.btnGroupSalesmanProduct_Click);
            // 
            // btnMatrixSalesmanProduct
            // 
            this.btnMatrixSalesmanProduct.Location = new System.Drawing.Point(387, 31);
            this.btnMatrixSalesmanProduct.Name = "btnMatrixSalesmanProduct";
            this.btnMatrixSalesmanProduct.Size = new System.Drawing.Size(200, 23);
            this.btnMatrixSalesmanProduct.TabIndex = 13;
            this.btnMatrixSalesmanProduct.Text = "Matrix Salesman Product";
            this.btnMatrixSalesmanProduct.UseVisualStyleBackColor = true;
            this.btnMatrixSalesmanProduct.Click += new System.EventHandler(this.btnMatrixSalesmanProduct_Click);
            // 
            // DesignForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnParentChildSalesmanProduct);
            this.Controls.Add(this.btnGroupSalesmanProduct);
            this.Controls.Add(this.btnMatrixSalesmanProduct);
            this.Controls.Add(this.btnHeaderDetail);
            this.Controls.Add(this.btnGlobalization);
            this.Controls.Add(this.btnReportBaseHeader);
            this.Controls.Add(this.btnReportInherit);
            this.Controls.Add(this.btnProduct);
            this.Name = "DesignForm";
            this.Text = "DesignForm";
            this.Load += new System.EventHandler(this.DesignForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Button btnProduct;
        private Button btnReportInherit;
        private Button btnReportBaseHeader;
        private Button btnGlobalization;
        private Button btnHeaderDetail;
        private Button btnParentChildSalesmanProduct;
        private Button btnGroupSalesmanProduct;
        private Button btnMatrixSalesmanProduct;
    }
}