﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FastReportBackResources
{
    public class Resources_Dummy_Class
    {
    }
}
