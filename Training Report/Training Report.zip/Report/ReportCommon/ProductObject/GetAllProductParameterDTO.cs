﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportCommon.ProductObject
{
    public class GetAllProductParameterDTO
    {
        public string CultureId { get; set; }
    }
}
