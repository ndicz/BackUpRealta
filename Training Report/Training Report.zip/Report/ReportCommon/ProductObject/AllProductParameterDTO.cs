﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportCommon.ProductObject
{
    public class AllProductParameterDTO
    {
        public int GenerateCountProduct { get; set; }
    }
}
