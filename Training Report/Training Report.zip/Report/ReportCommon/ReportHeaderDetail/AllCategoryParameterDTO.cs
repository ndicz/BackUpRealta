﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportCommon.ReportHeaderDetail
{
    public class AllCategoryParameterDTO
    {
        public int GenerateCountCategory { get; set; }
    }
}
