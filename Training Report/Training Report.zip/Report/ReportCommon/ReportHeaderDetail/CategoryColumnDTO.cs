﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportCommon.ReportHeaderDetail
{
    public class CategoryColumnDTO
    {
        public string ColCategoryId { get; set; } = "Category ID";
        public string ColCategoryName { get; set; } = "Category Name";
    }
}
