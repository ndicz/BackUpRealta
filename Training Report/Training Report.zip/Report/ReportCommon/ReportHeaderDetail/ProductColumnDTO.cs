﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportCommon.ReportHeaderDetail
{
    public class ProductColumnDTO
    {
        public string ColProductId { get; set; } = "Product ID";
        public string ColProductName { get; set; } = "Product Name";
    }
}
