﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportCommon.BaseHeader
{
    public class BaseHeaderDTO
    {
        public string CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string UserId { get; set; }
       public string UserName { get; set; }
    }
}
