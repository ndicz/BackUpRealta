﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReportCommon.SalesProduct
{
    public class AllSalesProductParameterDTO
    {
        public int GenerateCountSalesProduct { get; set; }
    }
}
